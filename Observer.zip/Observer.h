

#ifndef __OBSERVER_H__
#define __OBSERVER_H__

#include <stdlib.h>
#include <stdarg.h>

typedef struct {
	size_t size;
	void* (*ctor)(void *_self, void *params);
	void* (*dtor)(void *_self);
} AbstractClass;

typedef struct {
	size_t size;
	void* (*ctor)(void *_self, void *params);
	void* (*dtor)(void *_self);
	void (*attach)(void *_self, void *_obv);
	void (*detach)(void *_self, void *_obv);
	void (*notify)(const void *_self);
	void (*setstate)(void *_self, char *_st);
	char* (*getstate)(const void* _self);
} Subject;

typedef struct {
	const void *_;
	void *obvs;
	char *st;
} _DataSubject;

//const void *DataSubject;


typedef struct {
	size_t size;
	void* (*ctor)(void* _self, void *params);
	void* (*dtor)(void* _self);
	void (*update)(void *_self, const void *sub);
	void (*printinfo)(const void *_self);
} Observer;

typedef struct {
	const void *_;
	char *st;
	void *sub;
} _SheetObserver;

//const void *SheetObserver;

typedef struct {
	const void *_;
	char *st;
	void *sub;
} _ChatObserver;

//const void *ChatObserver;


typedef void (*Print_FN)(void *data);
typedef void (*Handle_FN)(void *node, void *params);

typedef struct {
	size_t size;
	void* (*ctor)(void *_self, void *params);
	void* (*dtor)(void *_self);
	void (*insert)(const void *_self, void *data);
	void (*remove)(const void *_self, void *data);
	void (*iterator)(const void *_self, Handle_FN hand_fn_cb, void *params);
	void (*print)(const void *_self, Print_FN print_fn_cb);
} List;


typedef struct _Node {
	void *data;
	struct _Node *next;
} Node;

typedef struct {
	const void *_;
	Node *head;
} _SingleList;

extern const void *SingleList;


void *New(const void *_class, void *params);
void Delete(void *_class);
void SetState(void *_subject, char *_st);
void Notify(const void *_subject);
void Update(void *_observer, const void *_subject);
void Insert(void *_list, void *_item);
void Remove(void *_list, void *_item);
void Iterator(const void *list, Handle_FN handle_fn_cb, void *params);
void Print(void *_list, Print_FN print_fn_cb);


#endif




